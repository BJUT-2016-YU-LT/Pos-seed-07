package com.thoughtworks.pos.common;

/**
 * Created by LL on 2016/6/27.
 */
public class PromoteAndTwo extends Exception {
}