package com.thoughtworks.pos.common;

public class EmptyIndex extends Exception {
    public EmptyIndex (){
        super("索引文件为空");
    }
}