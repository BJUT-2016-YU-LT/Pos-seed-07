package com.thoughtworks.pos.common;

/**
 * Created by Administrator on 2014/12/31.
 */
public class EmptyShoppingCartException extends Exception{
    public EmptyShoppingCartException()
    {
        super("没有商品");
    }
}