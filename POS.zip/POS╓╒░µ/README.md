POS-Seed
========

Seed project for POS terminal
